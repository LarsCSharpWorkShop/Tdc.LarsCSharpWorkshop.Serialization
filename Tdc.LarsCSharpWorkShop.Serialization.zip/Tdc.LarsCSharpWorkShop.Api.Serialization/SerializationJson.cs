using System;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Tdc.LarsCSharpWorkShop.Api.Serialization
{
    public static class SerializationJson
    {
        public static string Serialize(object value)
        {
            if (value != null)
            {
                try
                {
                    JsonSerializerOptions options = new()
                    {   
                       DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingDefault,
                        WriteIndented = true,                      
                    };
                    return System.Text.Json.JsonSerializer.Serialize(value, options);
                }
                catch (Exception ex)
                {
                    return "Unable to serialize the object. " + ex.Message;
                }
            }
            return $"The value is null and cannot be serialized.";
        }

        public static T Deserialize<T>(string value)
        {
            if (value != null)
            {
                try
                {
                    return System.Text.Json.JsonSerializer.Deserialize<T>(value);
                }
                catch
                {
                    return default;
                }
            }
            return default;
        }
    }
}
