﻿using Microsoft.Extensions.Hosting;
using System.Threading;
using System.Threading.Tasks;
using Tdc.LarsCSharpWorkShop.Api.Common;

namespace Tdc.LarsCSharpWorkShop.Serialization.Api
{
    public class Worker : BackgroundService
    {
        private readonly IHostApplicationLifetime iHostApplicationLifetime;
        public Worker(IHostApplicationLifetime iHostApplicationLifetime)
        {
            this.iHostApplicationLifetime = iHostApplicationLifetime;
        }
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {               
                // camel case
                // personSerialize
                // PersonSerialize

                // snake case
                // person_serialize
                // PERSON_SERIALIZE

                // kebab/hypen case
                // person-serialize
                // PERSON-SERIALIZE
                PersonSerialize personSerialize = new()
                {
                    aField = "aFiled",                    
                    bField = "bField",
                    Age = 60,
                    FirstName ="Lars",
                    LastName = "Thurman",
                    Street1 = "123 Main",
                    Street2 = null,
                    City = "a city",
                    State = "state",
                    PostalCode = "12345",
                   // PersonType = EnumPersonType.Friend
                };

                var json = Tdc.LarsCSharpWorkShop.Api.Serialization.SerializationJson.Serialize(personSerialize);
                PersonDeserialize personSerialize2 = Tdc.LarsCSharpWorkShop.Api.Serialization.SerializationJson.Deserialize<PersonDeserialize>(json);
                personSerialize2.State = "PA";
            }
            catch
            {
                throw;
            }
            finally
            {
                this.iHostApplicationLifetime.StopApplication();
            }
        }
    }
}
