﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Tdc.LarsCSharpWorkShop.Api.Common
{ 
    public enum EnumPersonType
    {         
    
        Friend =1,        
        Colleague,
        Family
    }
    
    public class PersonSerialize
    {
        public string aField;        
        public string bField;

        [JsonPropertyName("bField")]                
        public string BField => bField;
        public int Age { get; set; }
        // public PersonSerialize Child { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Street1 { get; set; }
        public string Street2 { get; set; }
 
        public string City { get; set; }        
        public string State { get; set; }
        public string PostalCode { get; set; }       

        public EnumPersonType PersonType { get; set; }
    }
}
