﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public interface IFolderConfig
    {
        List<FolderConfigSettings> FolderConfigSettings { get; set; }
    }

    public class FolderConfig: IFolderConfig
    {
       public List<FolderConfigSettings> FolderConfigSettings { get; set; }
        public static FolderConfig Load(IConfiguration config)
        {
            FolderConfig result = null;
            try
            {
                IConfigurationSection section = config.GetSection("FolderConfig");
                // section.Get requires Microsoft.Extensions.Hosting
                result = section?.Get<FolderConfig>();
            }
            catch (Exception ex)
            {
            }
            return result;
        }
    }

    public class FolderConfigSettings
    {
        public string Name { get; set; }
        public string Path { get; set; }
    }
}
